
const { Sequelize } = require('sequelize');

const sequelize = new Sequelize("db_sdirect", "root","", {
    host: "127.0.0.1",
    logging: false,
    dialect: "mysql"
    
});

sequelize.authenticate().then(async () => {
    console.log("db connected")
    await sequelize.sync();
}).catch((e) => {
    console.log(e)
})

module.exports = sequelize;